<?php
/**
 * ViaNexo - Ação de Autenticação do Gerente
 * Regras: Trate sempre as credenciais com Bcrypt (password_verify) e use PDO
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/bd.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../login.php');
}

$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$senha = trim($_POST['senha'] ?? '');

if (!$email || empty($senha)) {
    setToast('error', 'Dados Inválidos', 'Informe um e-mail válido e a sua senha de acesso.');
    redirect('../login.php');
}

try {
    // Consulta segura com PDO prepared statement
    $stmt = $pdo->prepare("SELECT id, nome, email, senha_hash, cargo, ativo FROM gerentes WHERE email = :email LIMIT 1");
    $stmt->execute([':email' => $email]);
    $gerente = $stmt->fetch();

    if ($gerente && (int)$gerente['ativo'] === 1 && password_verify($senha, $gerente['senha_hash'])) {
        // Autenticação bem-sucedida
        $_SESSION['gerente_id'] = $gerente['id'];
        $_SESSION['gerente_nome'] = $gerente['nome'];
        $_SESSION['gerente_email'] = $gerente['email'];
        $_SESSION['gerente_cargo'] = $gerente['cargo'];

        setToast('success', 'Autenticado', 'Bem-vindo ao Painel Gerencial ViaNexo, ' . htmlspecialchars($gerente['nome']) . '!');
        redirect('../dashboard.php');
    } else {
        setModal('danger', 'Credenciais Inválidas', 'E-mail ou senha incorretos, ou usuário inativo. Verifique os dados digitados.');
        redirect('../login.php');
    }

} catch (PDOException $e) {
    setModal('danger', 'Erro no Servidor', 'Ocorreu um erro ao processar a autenticação: ' . $e->getMessage());
    redirect('../login.php');
}
