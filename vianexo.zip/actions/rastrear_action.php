<?php
/**
 * ViaNexo - Ação de Autenticação e Consulta de Rastreamento
 * Regras:
 * 1. O usuário deve inserir ID e CPF para acessar a área restrita
 * 2. Toda encomenda tem ID; caso o ID não exista, informar que não foi encontrado
 * 3. O CPF/CNPJ é validado pelo Hash Seguro (HMAC-SHA256)
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/bd.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../index.php');
}

$codigo = strtoupper(trim($_POST['codigo_rastreio'] ?? ''));
$documento = trim($_POST['documento'] ?? '');

if (empty($codigo) || empty($documento)) {
    setModal('warning', 'Campos Obrigatórios', 'Por favor, preencha tanto o ID da Encomenda quanto o CPF/CNPJ do contratante/destinatário.');
    redirect('../index.php');
}

// 1. Verifica se o ID da encomenda existe no sistema
$stmt = $pdo->prepare("SELECT id, codigo_rastreio, cliente_id FROM encomendas WHERE UPPER(codigo_rastreio) = :codigo LIMIT 1");
$stmt->execute([':codigo' => $codigo]);
$encomenda = $stmt->fetch();

if (!$encomenda) {
    // Regra explícita: "caso o ID não existe deve se informar que não foi encontrado"
    setModal('danger', 'ID Não Encontrado', "O ID de encomenda \"{$codigo}\" não foi encontrado em nosso sistema. Verifique o código e tente novamente.");
    redirect('../index.php');
}

// 2. Calcula o Hash Seguro do documento informado para conferência com o contratante
$docHash = hashDoc($documento);

$stmtCliente = $pdo->prepare("SELECT id, nome, documento_mascarado FROM clientes WHERE id = :cliente_id AND documento_hash = :doc_hash LIMIT 1");
$stmtCliente->execute([
    ':cliente_id' => $encomenda['cliente_id'],
    ':doc_hash'    => $docHash
]);
$cliente = $stmtCliente->fetch();

if (!$cliente) {
    // O ID existe, porém o CPF/CNPJ não confere com o contratante vinculado ao ID
    setModal('warning', 'Acesso Não Autorizado', 'O CPF/CNPJ informado não confere com os registros do contratante deste ID de encomenda.');
    redirect('../index.php');
}

// Autorização de visualização da área restrita da encomenda concedida na sessão
$_SESSION['tracking_authorized_id'] = $encomenda['id'];
$_SESSION['tracking_authorized_codigo'] = $encomenda['codigo_rastreio'];

setToast('success', 'Rastreio Conectado', 'Acesso à área restrita da encomenda liberado com sucesso.');
redirect('../rastreio.php?codigo=' . urlencode($encomenda['codigo_rastreio']));
