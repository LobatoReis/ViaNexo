<?php
/**
 * ViaNexo - Ação de Atualização de Status e Rastreamento Logístico
 * Regras:
 * 1. O gerente tem acesso vitalício às informações do ID
 * 2. Informações de gerenciamento da encomenda só com pessoal da transportadora
 * 3. Status homologados: Pedido Registrado, Em Preparação, Em Transporte, Em rota de entrega, Entrega
 */

require_once __DIR__ . '/../includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../dashboard.php');
}

$encomenda_id      = filter_input(INPUT_POST, 'encomenda_id', FILTER_VALIDATE_INT);
$novo_status       = trim($_POST['status_atual'] ?? '');
$nova_localizacao  = trim($_POST['localizacao_atual'] ?? '');
$descricao_evento  = trim($_POST['descricao_evento'] ?? '');

// Atualizações operacionais restritas (Opcionais)
$motorista_nome       = trim($_POST['motorista_nome'] ?? '');
$veiculo_placa        = strtoupper(trim($_POST['veiculo_placa'] ?? ''));
$observacoes_internas = trim($_POST['observacoes_internas'] ?? '');

if (!$encomenda_id || empty($novo_status) || empty($nova_localizacao)) {
    setModal('warning', 'Dados Incompletos', 'Informe o novo status e a localização atual da encomenda.');
    redirect("../detalhes.php?id={$encomenda_id}");
}

if (!in_array($novo_status, STATUS_ENCOMENDA, true)) {
    setModal('danger', 'Status Inválido', 'O status informado não pertence ao fluxo homologado da ViaNexo.');
    redirect("../detalhes.php?id={$encomenda_id}");
}

if (empty($descricao_evento)) {
    $descricao_evento = "Status atualizado para '{$novo_status}' na unidade de {$nova_localizacao}.";
}

try {
    $pdo->beginTransaction();

    // 1. Atualiza dados da encomenda
    $stmtUpdate = $pdo->prepare("
        UPDATE encomendas 
        SET status_atual = :status,
            localizacao_atual = :localizacao,
            motorista_nome = COALESCE(NULLIF(:motorista, ''), motorista_nome),
            veiculo_placa = COALESCE(NULLIF(:placa, ''), veiculo_placa),
            observacoes_internas = COALESCE(NULLIF(:observacoes, ''), observacoes_internas),
            updated_at = NOW()
        WHERE id = :id
    ");

    $stmtUpdate->execute([
        ':status'       => $novo_status,
        ':localizacao'  => $nova_localizacao,
        ':motorista'    => $motorista_nome,
        ':placa'        => $veiculo_placa,
        ':observacoes'  => $observacoes_internas,
        ':id'           => $encomenda_id
    ]);

    // 2. Insere ponto de histórico
    $stmtHist = $pdo->prepare("
        INSERT INTO encomenda_historico (encomenda_id, status, localizacao, descricao_evento, data_hora)
        VALUES (:encomenda_id, :status, :localizacao, :descricao, NOW())
    ");

    $stmtHist->execute([
        ':encomenda_id' => $encomenda_id,
        ':status'       => $novo_status,
        ':localizacao'  => $nova_localizacao,
        ':descricao'    => $descricao_evento
    ]);

    $pdo->commit();

    setToast('success', 'Status Atualizado', "A encomenda agora está com status: {$novo_status}.");
    redirect("../detalhes.php?id={$encomenda_id}");

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    setModal('danger', 'Erro ao Atualizar', 'Falha ao registrar nova etapa: ' . $e->getMessage());
    redirect("../detalhes.php?id={$encomenda_id}");
}
