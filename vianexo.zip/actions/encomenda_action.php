<?php
/**
 * ViaNexo - Ação de Cadastro e Despacho de Encomenda
 * Regras:
 * 1. Toda encomenda tem ID (código de rastreio único)
 * 2. O sistema não deverá permitir o cadastro de duas encomendas com o mesmo ID
 * 3. Status iniciais dentro da lista homologada
 * 4. Informações restritas de logística armazenadas com segurança
 */

require_once __DIR__ . '/../includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../nova_encomenda.php');
}

$cliente_id        = filter_input(INPUT_POST, 'cliente_id', FILTER_VALIDATE_INT);
$codigo_rastreio   = strtoupper(trim($_POST['codigo_rastreio'] ?? ''));
$descricao_pacote  = trim($_POST['descricao_pacote'] ?? '');
$peso_kg           = filter_input(INPUT_POST, 'peso_kg', FILTER_VALIDATE_FLOAT) ?: 0.00;
$origem_cidade     = trim($_POST['origem_cidade'] ?? '');
$origem_uf         = strtoupper(trim($_POST['origem_uf'] ?? ''));
$destino_cidade    = trim($_POST['destino_cidade'] ?? '');
$destino_uf        = strtoupper(trim($_POST['destino_uf'] ?? ''));
$endereco_entrega  = trim($_POST['endereco_entrega'] ?? '');
$status_inicial    = trim($_POST['status_atual'] ?? 'Pedido Registrado');
$localizacao_atual = trim($_POST['localizacao_atual'] ?? '');
$previsao_entrega  = !empty($_POST['previsao_entrega']) ? $_POST['previsao_entrega'] : null;

// Informações restritas da transportadora
$motorista_nome      = trim($_POST['motorista_nome'] ?? '');
$veiculo_placa       = strtoupper(trim($_POST['veiculo_placa'] ?? ''));
$custo_frete         = filter_input(INPUT_POST, 'custo_frete', FILTER_VALIDATE_FLOAT) ?: 0.00;
$observacoes_internas = trim($_POST['observacoes_internas'] ?? '');

// Validações básicas
if (!$cliente_id || empty($descricao_pacote) || empty($origem_cidade) || empty($origem_uf) || empty($destino_cidade) || empty($destino_uf) || empty($endereco_entrega)) {
    setModal('warning', 'Dados Incompletos', 'Preencha todos os campos obrigatórios da encomenda e do endereço.');
    redirect('../nova_encomenda.php');
}

// Se o código não foi preenchido, gera automaticamente
if (empty($codigo_rastreio)) {
    $codigo_rastreio = generateTrackingCode($pdo);
}

// Validação de unicidade do ID: Regra "o sistema não devera permitir o cadastro de duas encomendas com o mesmo ID"
$stmtCheck = $pdo->prepare("SELECT id FROM encomendas WHERE UPPER(codigo_rastreio) = UPPER(:codigo) LIMIT 1");
$stmtCheck->execute([':codigo' => $codigo_rastreio]);
if ($stmtCheck->fetch()) {
    setModal(
        'danger',
        'ID Já Existente',
        "Regra violada: O sistema não permite o cadastro de duas encomendas com o mesmo ID! O código \"{$codigo_rastreio}\" já pertence a outra carga."
    );
    redirect('../nova_encomenda.php');
}

// Validação do status
if (!in_array($status_inicial, STATUS_ENCOMENDA, true)) {
    $status_inicial = 'Pedido Registrado';
}

if (empty($localizacao_atual)) {
    $localizacao_atual = "{$origem_cidade}/{$origem_uf} - Centro de Distribuição";
}

try {
    $pdo->beginTransaction();

    // Insere a encomenda
    $stmt = $pdo->prepare("
        INSERT INTO encomendas (
            codigo_rastreio, cliente_id, descricao_pacote, peso_kg,
            origem_cidade, origem_uf, destino_cidade, destino_uf,
            endereco_entrega, status_atual, localizacao_atual, previsao_entrega,
            motorista_nome, veiculo_placa, custo_frete, observacoes_internas
        ) VALUES (
            :codigo, :cliente_id, :descricao, :peso,
            :origem_cidade, :origem_uf, :destino_cidade, :destino_uf,
            :endereco, :status, :localizacao, :previsao,
            :motorista, :placa, :custo, :observacoes
        )
    ");

    $stmt->execute([
        ':codigo'        => $codigo_rastreio,
        ':cliente_id'    => $cliente_id,
        ':descricao'     => $descricao_pacote,
        ':peso'          => $peso_kg,
        ':origem_cidade' => $origem_cidade,
        ':origem_uf'     => $origem_uf,
        ':destino_cidade'=> $destino_cidade,
        ':destino_uf'    => $destino_uf,
        ':endereco'      => $endereco_entrega,
        ':status'        => $status_inicial,
        ':localizacao'   => $localizacao_atual,
        ':previsao'      => $previsao_entrega,
        ':motorista'     => $motorista_nome ?: null,
        ':placa'         => $veiculo_placa ?: null,
        ':custo'         => $custo_frete,
        ':observacoes'   => $observacoes_internas ?: null
    ]);

    $encomendaId = (int)$pdo->lastInsertId();

    // Cria o primeiro evento no histórico
    $stmtHist = $pdo->prepare("
        INSERT INTO encomenda_historico (encomenda_id, status, localizacao, descricao_evento, data_hora)
        VALUES (:encomenda_id, :status, :localizacao, :descricao, NOW())
    ");

    $stmtHist->execute([
        ':encomenda_id' => $encomendaId,
        ':status'       => $status_inicial,
        ':localizacao'  => $localizacao_atual,
        ':descricao'    => 'ID gerado pelo contratante e encomenda despachada no sistema ViaNexo.'
    ]);

    $pdo->commit();

    setToast('success', 'Encomenda Registrada', "ID {$codigo_rastreio} cadastrado com sucesso!");
    redirect('../detalhes.php?id=' . $encomendaId);

} catch (PDOException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    setModal('danger', 'Erro ao Registrar', 'Ocorreu um erro no banco de dados: ' . $e->getMessage());
    redirect('../nova_encomenda.php');
}
