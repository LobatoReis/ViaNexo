<?php
/**
 * ViaNexo - Ação de Encerramento de Sessão
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';

unset($_SESSION['gerente_id']);
unset($_SESSION['gerente_nome']);
unset($_SESSION['gerente_email']);
unset($_SESSION['gerente_cargo']);

setToast('info', 'Sessão Encerrada', 'Você saiu do sistema com segurança.');
redirect('../login.php');
