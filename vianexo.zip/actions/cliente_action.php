<?php
/**
 * ViaNexo - Ação de Gerenciamento de Contratantes/Clientes
 * Regras:
 * 1. O cliente não pode registrar o mesmo CPF/CNPJ 2 vezes
 * 2. O CNPJ/CPF deve ser armazenado com Hash Seguro (HMAC-SHA256 Blind Index)
 * 3. PDO para prevenção de SQL Injection
 */

require_once __DIR__ . '/../includes/auth_guard.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('../clientes.php');
}

$action = trim($_POST['action'] ?? 'create');
$nome = trim($_POST['nome'] ?? '');
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
$telefone = trim($_POST['telefone'] ?? '');
$tipo_documento = strtoupper(trim($_POST['tipo_documento'] ?? 'CPF'));
$documento = trim($_POST['documento'] ?? '');
$cidade = trim($_POST['cidade'] ?? '');
$estado = strtoupper(trim($_POST['estado'] ?? ''));

if (empty($nome) || empty($documento)) {
    setModal('warning', 'Campos Obrigatórios', 'O Nome/Razão Social e o CPF/CNPJ são campos obrigatórios.');
    redirect('../clientes.php');
}

$cleanDocumento = cleanDoc($documento);

// Validação matemática do documento
if ($tipo_documento === 'CPF') {
    if (!validateCpf($cleanDocumento)) {
        setModal('danger', 'CPF Inválido', 'O CPF informado não é válido. Verifique os dígitos informados.');
        redirect('../clientes.php');
    }
} else {
    $tipo_documento = 'CNPJ';
    if (!validateCnpj($cleanDocumento)) {
        setModal('danger', 'CNPJ Inválido', 'O CNPJ informado não é válido. Verifique os dígitos informados.');
        redirect('../clientes.php');
    }
}

// 1. Gera o Hash Seguro do Documento
$docHash = hashDoc($cleanDocumento);
$docMascara = maskDoc($cleanDocumento);

if ($action === 'create') {
    // 2. Regra: O cliente não pode registrar o mesmo CPF/CNPJ 2 vezes
    $stmtCheck = $pdo->prepare("SELECT id, nome FROM clientes WHERE documento_hash = :hash LIMIT 1");
    $stmtCheck->execute([':hash' => $docHash]);
    $existente = $stmtCheck->fetch();

    if ($existente) {
        setModal(
            'danger',
            'Documento Já Registrado',
            "Regra de Negócio: O cliente não pode registrar o mesmo CPF/CNPJ 2 vezes. Já existe um contratante registrado com este documento ({$docMascara}): " . htmlspecialchars($existente['nome'])
        );
        redirect('../clientes.php');
    }

    try {
        $stmtInsert = $pdo->prepare("
            INSERT INTO clientes (nome, email, telefone, tipo_documento, documento_hash, documento_mascarado, cidade, estado)
            VALUES (:nome, :email, :telefone, :tipo_documento, :documento_hash, :documento_mascarado, :cidade, :estado)
        ");

        $stmtInsert->execute([
            ':nome'                => $nome,
            ':email'               => $email ?: null,
            ':telefone'            => $telefone ?: null,
            ':tipo_documento'      => $tipo_documento,
            ':documento_hash'      => $docHash,
            ':documento_mascarado' => $docMascara,
            ':cidade'              => $cidade ?: null,
            ':estado'              => $estado ?: null,
        ]);

        setToast('success', 'Contratante Cadastrado', 'Contratante registrado com sucesso e hash seguro gerado.');
        redirect('../clientes.php');

    } catch (PDOException $e) {
        setModal('danger', 'Erro no Banco de Dados', 'Falha ao cadastrar contratante: ' . $e->getMessage());
        redirect('../clientes.php');
    }
}
