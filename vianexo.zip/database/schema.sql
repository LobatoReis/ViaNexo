-- ==============================================================================
-- ViaNexo - Sistema de Logística e Rastreamento de Encomendas
-- Arquivo de Estrutura do Banco de Dados (MySQL / MariaDB)
-- ==============================================================================

CREATE DATABASE IF NOT EXISTS `vianexo_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `vianexo_db`;

-- ------------------------------------------------------------------------------
-- 1. Tabela: gerentes (Acesso vitalício aos IDs e gerenciamento interno)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `gerentes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nome` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) NOT NULL UNIQUE,
    `senha_hash` VARCHAR(255) NOT NULL COMMENT 'Credencial tratada com Bcrypt',
    `cargo` VARCHAR(100) DEFAULT 'Gerente de Logística',
    `ativo` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2. Tabela: clientes (Contratantes geradores de ID)
-- Regra: Não permitir mesmo CPF/CNPJ 2 vezes; Armazenamento em Hash Seguro (Blind Index HMAC-SHA256)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `clientes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `nome` VARCHAR(150) NOT NULL,
    `email` VARCHAR(191) NULL,
    `telefone` VARCHAR(30) NULL,
    `tipo_documento` ENUM('CPF', 'CNPJ') NOT NULL DEFAULT 'CPF',
    `documento_hash` CHAR(64) NOT NULL UNIQUE COMMENT 'Hash seguro (Blind Index HMAC-SHA256) para busca e garantia de unicidade',
    `documento_mascarado` VARCHAR(30) NOT NULL COMMENT 'Exibição amigável sem expor dados confidenciais',
    `cidade` VARCHAR(100) NULL,
    `estado` CHAR(2) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3. Tabela: encomendas
-- Regra: Toda encomenda tem ID único (codigo_rastreio). Nenhuma duplicata permitida.
-- Status permitidos: 'Pedido Registrado', 'Em Preparação', 'Em Transporte', 'Em rota de entrega', 'Entrega'
-- Informações restritas da transportadora separadas para controle interno.
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `encomendas` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `codigo_rastreio` VARCHAR(50) NOT NULL UNIQUE COMMENT 'ID único de identificação e rastreio da encomenda',
    `cliente_id` INT NOT NULL COMMENT 'Contratante vinculado que gerou o pedido',
    `descricao_pacote` VARCHAR(255) NOT NULL,
    `peso_kg` DECIMAL(8,2) DEFAULT 0.00,
    `origem_cidade` VARCHAR(100) NOT NULL,
    `origem_uf` CHAR(2) NOT NULL,
    `destino_cidade` VARCHAR(100) NOT NULL,
    `destino_uf` CHAR(2) NOT NULL,
    `endereco_entrega` VARCHAR(255) NOT NULL,
    `status_atual` ENUM('Pedido Registrado', 'Em Preparação', 'Em Transporte', 'Em rota de entrega', 'Entrega') NOT NULL DEFAULT 'Pedido Registrado',
    `localizacao_atual` VARCHAR(150) NOT NULL DEFAULT 'Centro de Distribuição Origem',
    `previsao_entrega` DATE NULL,
    
    -- Dados de Gestão Restrita (Exclusivos da Transportadora / Gerente)
    `motorista_nome` VARCHAR(120) NULL COMMENT 'Uso interno da transportadora',
    `veiculo_placa` VARCHAR(20) NULL COMMENT 'Uso interno da transportadora',
    `custo_frete` DECIMAL(10,2) DEFAULT 0.00 COMMENT 'Uso interno da transportadora',
    `observacoes_internas` TEXT NULL COMMENT 'Uso interno da transportadora',
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    CONSTRAINT `fk_encomendas_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 4. Tabela: encomenda_historico (Timeline e checkpoint de localização)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `encomenda_historico` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `encomenda_id` INT NOT NULL,
    `status` ENUM('Pedido Registrado', 'Em Preparação', 'Em Transporte', 'Em rota de entrega', 'Entrega') NOT NULL,
    `localizacao` VARCHAR(150) NOT NULL,
    `descricao_evento` VARCHAR(255) NOT NULL,
    `data_hora` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT `fk_historico_encomenda` FOREIGN KEY (`encomenda_id`) REFERENCES `encomendas` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- Carga Inicial de Testes (Seeds)
-- Gerente inicial (Senha: admin123)
-- Hash Bcrypt para "admin123": $2y$10$vI8aWBnW3fID.ZQ4/zo1G.q1lRps.9cGLcZEiGDMVr5yUP1KUOYTa
-- ------------------------------------------------------------------------------
INSERT INTO `gerentes` (`nome`, `email`, `senha_hash`, `cargo`)
VALUES ('Carlos Gerente ViaNexo', 'gerente@vianexo.com.br', '$2y$10$vI8aWBnW3fID.ZQ4/zo1G.q1lRps.9cGLcZEiGDMVr5yUP1KUOYTa', 'Gerente Geral de Logística')
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Cliente 1: Contratante exemplo (CPF: 123.456.789-01 -> hash hmac sha256 com secret padrão)
INSERT INTO `clientes` (`id`, `nome`, `email`, `telefone`, `tipo_documento`, `documento_hash`, `documento_mascarado`, `cidade`, `estado`)
VALUES (1, 'Tech Importações LTDA', 'contato@techimport.com', '(11) 98765-4321', 'CPF', '0d045908b0772b4f2dedf897c6e9fc1584b455419943773b671c9ea9ac167220', '***.456.789-**', 'São Paulo', 'SP')
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Encomenda 1: Exemplo com ID VNX-BR782190
INSERT INTO `encomendas` (`id`, `codigo_rastreio`, `cliente_id`, `descricao_pacote`, `peso_kg`, `origem_cidade`, `origem_uf`, `destino_cidade`, `destino_uf`, `endereco_entrega`, `status_atual`, `localizacao_atual`, `previsao_entrega`, `motorista_nome`, `veiculo_placa`, `custo_frete`, `observacoes_internas`)
VALUES (1, 'VNX-BR782190', 1, 'Lote de Dispositivos Eletrônicos (Smartphones)', 14.50, 'São Paulo', 'SP', 'Curitiba', 'PR', 'Av. Sete de Setembro, 1500 - Sala 402', 'Em Transporte', 'Centro de Triagem Logística - Registro/SP', DATE_ADD(CURRENT_DATE, INTERVAL 2 DAY), 'Marcos Oliveira', 'ABC-4E21', 340.00, 'Carga frágil com seguro ativado. Despachado sem avarias.')
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Histórico da Encomenda 1
INSERT INTO `encomenda_historico` (`encomenda_id`, `status`, `localizacao`, `descricao_evento`, `data_hora`)
VALUES 
(1, 'Pedido Registrado', 'São Paulo/SP', 'ID gerado pelo contratante e pedido registrado no sistema ViaNexo', DATE_SUB(NOW(), INTERVAL 2 DAY)),
(1, 'Em Preparação', 'Centro de Logística SP Capital', 'Carga paletizada e nota fiscal conferida', DATE_SUB(NOW(), INTERVAL 1 DAY)),
(1, 'Em Transporte', 'Centro de Triagem Logística - Registro/SP', 'Veículo em trânsito pela Rodovia Régis Bittencourt', NOW())
ON DUPLICATE KEY UPDATE `id`=`id`;
