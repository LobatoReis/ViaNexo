<?php
/**
 * ViaNexo - Configurações Gerais da Aplicação
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configuração de Fuso Horário
date_default_timezone_set('America/Sao_Paulo');

// Constantes da Aplicação
define('APP_NAME', 'ViaNexo Logística');
define('APP_VERSION', '1.0.0');

// Chave Secreta para Blind Indexing (HMAC-SHA256) do CPF/CNPJ
// Garante armazenamento com Hash Seguro e impossibilita engenharia reversa do documento no BD
define('APP_KEY', 'vianexo_secret_key_2026');

// Definição Oficial dos Status de Encomenda (Conforme requisitos)
define('STATUS_ENCOMENDA', [
    'Pedido Registrado',
    'Em Preparação',
    'Em Transporte',
    'Em rota de entrega',
    'Entrega'
]);

// Configurações do Banco de Dados MySQL
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'vianexo_db');
define('DB_USER', 'root');
define('DB_PASS', ''); // Altere conforme seu ambiente local (XAMPP / Laragon / Docker)
