<?php
/**
 * ViaNexo - Conexão Segura com MySQL via PDO
 * Regra: Sempre utilizar PDO com Prepared Statements para prevenção de SQL Injection.
 */

require_once __DIR__ . '/config.php';

try {
    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false, // Usa prepared statements nativos do MySQL
    ];

    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);

    // Auto-instalação da base de dados caso a tabela ainda não exista
    autoInstallViaNexo($pdo);

} catch (PDOException $e) {
    // Se a base de dados não existir, tenta criar automaticamente
    if ($e->getCode() == 1049) {
        try {
            $rootPdo = new PDO("mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";charset=utf8mb4", DB_USER, DB_PASS);
            $rootPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            autoInstallViaNexo($pdo);
        } catch (Exception $inner) {
            die("Erro crítico ao criar e conectar ao banco de dados: " . htmlspecialchars($inner->getMessage()));
        }
    } else {
        die("Erro de conexão PDO com o banco de dados: " . htmlspecialchars($e->getMessage()));
    }
}

/**
 * Função utilitária para inicialização automática do banco caso esteja vazio
 */
function autoInstallViaNexo(PDO $pdo): void {
    try {
        $check = $pdo->query("SHOW TABLES LIKE 'gerentes'")->fetch();
        if (!$check) {
            $schemaFile = __DIR__ . '/../database/schema.sql';
            if (file_exists($schemaFile)) {
                $sql = file_get_contents($schemaFile);
                // Executa instrução por instrução para máxima compatibilidade com qualquer driver PDO
                $queries = array_filter(array_map('trim', explode(';', $sql)));
                foreach ($queries as $query) {
                    if (!empty($query)) {
                        $pdo->exec($query);
                    }
                }
            }
        }
    } catch (Exception $e) {
        // Ignora ou trata erro sem quebrar o bootstrap
    }
}
