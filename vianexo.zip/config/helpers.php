<?php
/**
 * ViaNexo - Funções Utilitárias e de Segurança
 */

require_once __DIR__ . '/config.php';

/**
 * Remove qualquer caractere que não seja número do documento
 */
function cleanDoc(string $doc): string {
    return preg_replace('/\D/', '', $doc);
}

/**
 * Gera o Hash Seguro (Blind Index HMAC-SHA256) do CPF/CNPJ
 * Cumpre a regra de que CPF/CNPJ nunca é gravado em texto puro e permite busca determinística exata
 */
function hashDoc(string $doc): string {
    $clean = cleanDoc($doc);
    return hash_hmac('sha256', $clean, APP_KEY);
}

/**
 * Gera máscara para exibição visual segura do documento
 */
function maskDoc(string $doc): string {
    $clean = cleanDoc($doc);
    $len = strlen($clean);

    if ($len === 11) { // CPF: ***.456.789-**
        return '***.' . substr($clean, 3, 3) . '.' . substr($clean, 6, 3) . '-**';
    } elseif ($len === 14) { // CNPJ: **.***.456/0001-**
        return '**.***.' . substr($clean, 5, 3) . '/' . substr($clean, 8, 4) . '-**';
    }

    return '***.***.***-**';
}

/**
 * Validação algorítmica de CPF
 */
function validateCpf(string $cpf): bool {
    $cpf = cleanDoc($cpf);
    if (strlen($cpf) !== 11 || preg_match('/^(\d)\1*$/', $cpf)) {
        return false;
    }
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    return true;
}

/**
 * Validação algorítmica de CNPJ
 */
function validateCnpj(string $cnpj): bool {
    $cnpj = cleanDoc($cnpj);
    if (strlen($cnpj) !== 14 || preg_match('/^(\d)\1*$/', $cnpj)) {
        return false;
    }
    $tamanhos = [12, 13];
    foreach ($tamanhos as $tamanho) {
        $soma = 0;
        $pos = $tamanho - 7;
        for ($i = $tamanho; $i >= 1; $i--) {
            $soma += $cnpj[$tamanho - $i] * $pos--;
            if ($pos < 2) $pos = 9;
        }
        $resto = $soma % 11;
        $digito = $resto < 2 ? 0 : 11 - $resto;
        if ($cnpj[$tamanho] != $digito) {
            return false;
        }
    }
    return true;
}

/**
 * Gera um ID de encomenda único (código de rastreio) no formato VNX-XXXXXX
 * Valida no banco para garantir que não exista nenhuma encomenda com o mesmo ID
 */
function generateTrackingCode(PDO $pdo): string {
    $exists = true;
    $code = '';

    while ($exists) {
        $random = strtoupper(bin2hex(random_bytes(3))); // 6 caracteres hexadecimais
        $code = 'VNX-' . $random;

        $stmt = $pdo->prepare("SELECT id FROM encomendas WHERE codigo_rastreio = :codigo");
        $stmt->execute([':codigo' => $code]);
        if (!$stmt->fetch()) {
            $exists = false;
        }
    }

    return $code;
}

/**
 * Define uma notificação Toast na sessão (Sucesso, Erro, Alerta, Info)
 */
function setToast(string $type, string $title, string $message): void {
    $_SESSION['flash_toast'] = [
        'type'    => $type, // 'success', 'error', 'warning', 'info'
        'title'   => $title,
        'message' => $message
    ];
}

/**
 * Define uma notificação Modal de Contrato na sessão (Avisos de impacto, confirmações ou erros críticos)
 */
function setModal(string $type, string $title, string $message): void {
    $_SESSION['flash_modal'] = [
        'type'    => $type, // 'danger', 'info', 'success'
        'title'   => $title,
        'message' => $message
    ];
}

/**
 * Recupera e consome o Toast da sessão
 */
function getFlashToast(): ?array {
    if (isset($_SESSION['flash_toast'])) {
        $toast = $_SESSION['flash_toast'];
        unset($_SESSION['flash_toast']);
        return $toast;
    }
    return null;
}

/**
 * Recupera e consome o Modal da sessão
 */
function getFlashModal(): ?array {
    if (isset($_SESSION['flash_modal'])) {
        $modal = $_SESSION['flash_modal'];
        unset($_SESSION['flash_modal']);
        return $modal;
    }
    return null;
}

/**
 * Retorna o índice numérico (0 a 4) do status da encomenda para o stepper visual
 */
function getStatusStepIndex(string $status): int {
    $index = array_search($status, STATUS_ENCOMENDA);
    return ($index !== false) ? (int)$index : 0;
}

/**
 * Retorna classes de cores do Tailwind para badges de status
 */
function getStatusBadgeClass(string $status): string {
    return match ($status) {
        'Pedido Registrado'  => 'bg-blue-100 text-blue-800 border-blue-300 dark:bg-blue-900/40 dark:text-blue-300 dark:border-blue-700',
        'Em Preparação'     => 'bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-900/40 dark:text-amber-300 dark:border-amber-700',
        'Em Transporte'      => 'bg-indigo-100 text-indigo-800 border-indigo-300 dark:bg-indigo-900/40 dark:text-indigo-300 dark:border-indigo-700',
        'Em rota de entrega' => 'bg-purple-100 text-purple-800 border-purple-300 dark:bg-purple-900/40 dark:text-purple-300 dark:border-purple-700',
        'Entrega'            => 'bg-emerald-100 text-emerald-800 border-emerald-300 dark:bg-emerald-900/40 dark:text-emerald-300 dark:border-emerald-700',
        default              => 'bg-gray-100 text-gray-800 border-gray-300 dark:bg-gray-800 dark:text-gray-300 dark:border-gray-700',
    };
}

/**
 * Formata data/hora para padrão brasileiro d/m/Y às H:i
 */
function formatDateBr(?string $datetime): string {
    if (!$datetime) return 'Não definida';
    return date('d/m/Y \à\s H:i', strtotime($datetime));
}

/**
 * Formata apenas data d/m/Y
 */
function formatDateOnlyBr(?string $date): string {
    if (!$date) return 'A definir';
    return date('d/m/Y', strtotime($date));
}

/**
 * Redirecionamento seguro
 */
function redirect(string $url): void {
    header("Location: " . $url);
    exit;
}
