    </main>

    <!-- Rodapé Global -->
    <footer class="bg-slate-900 text-slate-400 text-sm mt-auto border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                <!-- Coluna 1: Sobre -->
                <div>
                    <div class="flex items-center gap-2 mb-3">
                        <div class="w-8 h-8 rounded-lg bg-brand-600 flex items-center justify-center text-white">
                            <i class="fa-solid fa-truck-fast text-sm"></i>
                        </div>
                        <span class="text-lg font-bold text-white tracking-tight">ViaNexo</span>
                    </div>
                    <p class="text-xs text-slate-400 leading-relaxed mb-4">
                        Sistema modular de logística inteligente. Rastreamento seguro com blind indexing (HMAC-SHA256) e gerenciamento de frotas com acesso vitalício para operadores.
                    </p>
                    <div class="flex items-center gap-2 text-xs text-emerald-400">
                        <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span>Serviço Operacional Online</span>
                    </div>
                </div>

                <!-- Coluna 2: Especificações Técnicas -->
                <div>
                    <h5 class="text-xs font-semibold text-white uppercase tracking-wider mb-3">Arquitetura & Segurança</h5>
                    <ul class="space-y-2 text-xs">
                        <li class="flex items-center gap-2">
                            <i class="fa-solid fa-lock text-brand-500"></i>
                            <span>Credenciais com Bcrypt</span>
                        </li>
                        <li class="flex items-center gap-2">
                            <i class="fa-solid fa-fingerprint text-brand-500"></i>
                            <span>CPF/CNPJ Seguro (Blind Index HMAC)</span>
                        </li>
                        <li class="flex items-center gap-2">
                            <i class="fa-solid fa-database text-brand-500"></i>
                            <span>MySQL com PDO Prepared Statements</span>
                        </li>
                        <li class="flex items-center gap-2">
                            <i class="fa-solid fa-mobile-screen text-brand-500"></i>
                            <span>Interface Mobile-First Tailwind CSS</span>
                        </li>
                    </ul>
                </div>

                <!-- Coluna 3: Status Oficiais -->
                <div>
                    <h5 class="text-xs font-semibold text-white uppercase tracking-wider mb-3">Ciclo da Encomenda</h5>
                    <div class="flex flex-wrap gap-1.5">
                        <span class="px-2 py-1 bg-slate-800 text-[11px] rounded text-slate-300">1. Pedido Registrado</span>
                        <span class="px-2 py-1 bg-slate-800 text-[11px] rounded text-slate-300">2. Em Preparação</span>
                        <span class="px-2 py-1 bg-slate-800 text-[11px] rounded text-slate-300">3. Em Transporte</span>
                        <span class="px-2 py-1 bg-slate-800 text-[11px] rounded text-slate-300">4. Em rota de entrega</span>
                        <span class="px-2 py-1 bg-emerald-900/60 text-[11px] rounded text-emerald-300 font-semibold">5. Entrega</span>
                    </div>
                    <div class="mt-4 pt-3 border-t border-slate-800 text-xs">
                        <a href="login.php" class="text-brand-400 hover:text-brand-300 transition-colors">
                            <i class="fa-solid fa-user-shield mr-1"></i> Acesso Restrito da Transportadora &rarr;
                        </a>
                    </div>
                </div>
            </div>

            <!-- Copyright -->
            <div class="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
                <p>&copy; <?= date('Y') ?> ViaNexo Logística Integrada. Todos os direitos reservados.</p>
                <div class="flex items-center gap-4 text-slate-500">
                    <span>Privacidade & LGPD</span>
                    <span>•</span>
                    <span>Termos de Transporte</span>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts Globais para Mobile Toggle e Máscaras de Input -->
    <script>
        // Toggle Menu Mobile
        const menuBtn = document.getElementById('mobile-menu-btn');
        const mobileMenu = document.getElementById('mobile-menu');
        const menuIcon = document.getElementById('menu-icon');

        if (menuBtn && mobileMenu) {
            menuBtn.addEventListener('click', () => {
                const isHidden = mobileMenu.classList.contains('hidden');
                if (isHidden) {
                    mobileMenu.classList.remove('hidden');
                    menuIcon.classList.remove('fa-bars');
                    menuIcon.classList.add('fa-xmark');
                } else {
                    mobileMenu.classList.add('hidden');
                    menuIcon.classList.remove('fa-xmark');
                    menuIcon.classList.add('fa-bars');
                }
            });
        }

        // Função de Máscara de CPF / CNPJ Dinâmica
        function maskCpfCnpj(input) {
            let v = input.value.replace(/\D/g, '');
            if (v.length <= 11) {
                // CPF: 000.000.000-00
                v = v.replace(/(\d{3})(\d)/, '$1.$2');
                v = v.replace(/(\d{3})(\d)/, '$1.$2');
                v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
            } else {
                // CNPJ: 00.000.000/0000-00
                v = v.substring(0, 14);
                v = v.replace(/^(\d{2})(\d)/, '$1.$2');
                v = v.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
                v = v.replace(/\.(\d{3})(\d)/, '.$1/$2');
                v = v.replace(/(\d{4})(\d)/, '$1-$2');
            }
            input.value = v;
        }

        // Máscara de CEP
        function maskCep(input) {
            let v = input.value.replace(/\D/g, '').substring(0, 8);
            v = v.replace(/^(\d{5})(\d)/, '$1-$2');
            input.value = v;
        }

        // Formatação de ID de Encomenda para Maiúsculas
        function formatTrackingInput(input) {
            input.value = input.value.toUpperCase().trim();
        }
    </script>
</body>
</html>
