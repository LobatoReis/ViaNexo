<?php
/**
 * ViaNexo - Header Global (Tailwind CSS, Mobile-First, Responsivo)
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';

$isLoggedIn = isset($_SESSION['gerente_id']) && !empty($_SESSION['gerente_id']);
$gerenteNome = $_SESSION['gerente_nome'] ?? 'Gerente';
?>
<!DOCTYPE html>
<html lang="pt-BR" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle ?? 'ViaNexo - Sistema de Logística Inteligente') ?></title>
    
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: {
                            50: '#eef2ff',
                            100: '#e0e7ff',
                            500: '#6366f1',
                            600: '#4f46e5',
                            700: '#4338ca',
                            800: '#3730a3',
                            900: '#312e81',
                        }
                    }
                }
            }
        }
    </script>
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        [x-cloak] { display: none !important; }
        .glass-panel {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(8px);
        }
    </style>
</head>
<body class="flex flex-col min-h-screen text-slate-800 antialiased selection:bg-brand-500 selection:text-white">

    <!-- Navegação Principal Responsiva (Mobile First) -->
    <header class="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200 shadow-sm transition-all">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16 sm:h-20">
                
                <!-- Logo & Marca -->
                <div class="flex items-center gap-3">
                    <a href="index.php" class="flex items-center gap-3 group">
                        <div class="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-tr from-brand-700 via-brand-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-brand-500/20 group-hover:scale-105 transition-transform">
                            <i class="fa-solid fa-truck-fast text-lg sm:text-xl"></i>
                        </div>
                        <div>
                            <span class="text-xl sm:text-2xl font-black tracking-tight text-slate-900 flex items-center gap-1">
                                Via<span class="text-brand-600">Nexo</span>
                            </span>
                            <span class="hidden sm:block text-[10px] font-semibold tracking-wider uppercase text-slate-400">Logística & Rastreio</span>
                        </div>
                    </a>
                </div>

                <!-- Links Desktop -->
                <nav class="hidden md:flex items-center gap-1">
                    <a href="index.php" class="px-3.5 py-2 text-sm font-medium rounded-lg text-slate-600 hover:text-brand-600 hover:bg-slate-100 transition-colors <?= (!isset($activeNav) || $activeNav === 'home') ? 'bg-slate-100 text-brand-600 font-semibold' : '' ?>">
                        <i class="fa-solid fa-magnifying-glass-location mr-1.5 opacity-70"></i> Rastrear Encomenda
                    </a>

                    <?php if ($isLoggedIn): ?>
                        <a href="dashboard.php" class="px-3.5 py-2 text-sm font-medium rounded-lg text-slate-600 hover:text-brand-600 hover:bg-slate-100 transition-colors <?= (isset($activeNav) && $activeNav === 'dashboard') ? 'bg-slate-100 text-brand-600 font-semibold' : '' ?>">
                            <i class="fa-solid fa-gauge-high mr-1.5 opacity-70"></i> Painel Geral
                        </a>
                        <a href="nova_encomenda.php" class="px-3.5 py-2 text-sm font-medium rounded-lg text-slate-600 hover:text-brand-600 hover:bg-slate-100 transition-colors <?= (isset($activeNav) && $activeNav === 'nova_encomenda') ? 'bg-slate-100 text-brand-600 font-semibold' : '' ?>">
                            <i class="fa-solid fa-plus-circle mr-1.5 opacity-70"></i> Despachar Encomenda
                        </a>
                        <a href="clientes.php" class="px-3.5 py-2 text-sm font-medium rounded-lg text-slate-600 hover:text-brand-600 hover:bg-slate-100 transition-colors <?= (isset($activeNav) && $activeNav === 'clientes') ? 'bg-slate-100 text-brand-600 font-semibold' : '' ?>">
                            <i class="fa-solid fa-building-user mr-1.5 opacity-70"></i> Contratantes
                        </a>
                    <?php endif; ?>
                </nav>

                <!-- Botões de Ação do Usuário / Gerente -->
                <div class="hidden md:flex items-center gap-3">
                    <?php if ($isLoggedIn): ?>
                        <div class="flex items-center gap-3 pl-3 border-l border-slate-200">
                            <div class="text-right">
                                <p class="text-xs font-semibold text-slate-900 leading-tight"><?= htmlspecialchars($gerenteNome) ?></p>
                                <span class="text-[11px] text-emerald-600 font-medium flex items-center justify-end gap-1">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Gerente Ativo
                                </span>
                            </div>
                            <a href="actions/logout_action.php" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200 transition-colors" title="Encerrar Sessão">
                                <i class="fa-solid fa-arrow-right-from-bracket"></i> Sair
                            </a>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-300">
                            <i class="fa-solid fa-lock text-brand-600"></i> Área do Gerente
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Botão Menu Mobile Hamburguer -->
                <div class="flex md:hidden items-center">
                    <button id="mobile-menu-btn" type="button" class="p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 focus:outline-none" aria-label="Abrir Menu">
                        <i id="menu-icon" class="fa-solid fa-bars text-xl"></i>
                    </button>
                </div>

            </div>
        </div>

        <!-- Menu Mobile Retrátil -->
        <div id="mobile-menu" class="hidden md:hidden border-t border-slate-200 bg-white px-4 pt-2 pb-6 space-y-2 shadow-lg animate-fadeIn">
            <a href="index.php" class="block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-100">
                <i class="fa-solid fa-magnifying-glass-location w-6 text-brand-600"></i> Rastrear Encomenda
            </a>

            <?php if ($isLoggedIn): ?>
                <a href="dashboard.php" class="block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-100">
                    <i class="fa-solid fa-gauge-high w-6 text-brand-600"></i> Painel da Transportadora
                </a>
                <a href="nova_encomenda.php" class="block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-100">
                    <i class="fa-solid fa-plus-circle w-6 text-brand-600"></i> Despachar Encomenda
                </a>
                <a href="clientes.php" class="block px-3 py-2.5 rounded-lg text-base font-medium text-slate-700 hover:bg-slate-100">
                    <i class="fa-solid fa-building-user w-6 text-brand-600"></i> Contratantes
                </a>
                
                <div class="pt-4 border-t border-slate-200">
                    <div class="px-3 py-2">
                        <p class="text-sm font-semibold text-slate-800"><?= htmlspecialchars($gerenteNome) ?></p>
                        <p class="text-xs text-slate-500">Sessão Gerencial Ativa</p>
                    </div>
                    <a href="actions/logout_action.php" class="flex items-center gap-2 px-3 py-2.5 text-base font-medium text-rose-600 hover:bg-rose-50 rounded-lg">
                        <i class="fa-solid fa-arrow-right-from-bracket w-6"></i> Desconectar
                    </a>
                </div>
            <?php else: ?>
                <div class="pt-3 border-t border-slate-200">
                    <a href="login.php" class="flex items-center justify-center gap-2 w-full px-4 py-2.5 text-sm font-semibold text-white bg-brand-600 hover:bg-brand-700 rounded-lg shadow-sm">
                        <i class="fa-solid fa-lock"></i> Entrar como Gerente
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </header>

    <!-- Inclusão Automática de Mensagens Flash (Toasts e Modais) -->
    <?php require_once __DIR__ . '/toast.php'; ?>

    <main class="flex-grow">
