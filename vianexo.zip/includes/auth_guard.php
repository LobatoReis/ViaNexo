<?php
/**
 * ViaNexo - Middleware de Proteção de Rotas do Gerente
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/helpers.php';
require_once __DIR__ . '/../config/bd.php';

if (!isset($_SESSION['gerente_id']) || empty($_SESSION['gerente_id'])) {
    setModal('warning', 'Acesso Restrito', 'Você precisa estar autenticado como Gerente da Transportadora para acessar esta área.');
    redirect('login.php');
}

/**
 * Retorna os dados do gerente logado
 */
function getCurrentGerente(PDO $pdo): ?array {
    if (!isset($_SESSION['gerente_id'])) return null;
    
    $stmt = $pdo->prepare("SELECT id, nome, email, cargo FROM gerentes WHERE id = :id AND ativo = 1");
    $stmt->execute([':id' => $_SESSION['gerente_id']]);
    $gerente = $stmt->fetch();

    if (!$gerente) {
        unset($_SESSION['gerente_id']);
        unset($_SESSION['gerente_nome']);
        redirect('login.php');
    }

    return $gerente;
}
