<?php
/**
 * ViaNexo - Componente de Notificações Flash (Toast e Modal)
 * Regra: Retornar mensagens de erro de forma clara na interface para o usuário (TOAST e MODAIS).
 */

$flashToast = getFlashToast();
$flashModal = getFlashModal();
?>

<!-- Container Global para Toasts Flutuantes -->
<div id="toast-container" class="fixed top-20 right-4 z-50 flex flex-col gap-3 max-w-sm w-full pointer-events-none px-4 sm:px-0">
    <?php if ($flashToast): ?>
        <?php
            $tColor = match ($flashToast['type']) {
                'success' => 'border-emerald-500 bg-emerald-50 text-emerald-900',
                'error'   => 'border-rose-500 bg-rose-50 text-rose-900',
                'warning' => 'border-amber-500 bg-amber-50 text-amber-900',
                default   => 'border-blue-500 bg-blue-50 text-blue-900',
            };
            $tIcon = match ($flashToast['type']) {
                'success' => 'fa-circle-check text-emerald-500',
                'error'   => 'fa-triangle-exclamation text-rose-500',
                'warning' => 'fa-circle-exclamation text-amber-500',
                default   => 'fa-circle-info text-blue-500',
            };
        ?>
        <div class="toast-item pointer-events-auto flex items-start gap-3 p-4 rounded-xl border shadow-xl transition-all duration-300 transform translate-y-0 opacity-100 <?= $tColor ?>">
            <i class="fa-solid <?= $tIcon ?> text-xl mt-0.5"></i>
            <div class="flex-1">
                <h4 class="font-bold text-sm"><?= htmlspecialchars($flashToast['title']) ?></h4>
                <p class="text-xs mt-0.5 opacity-90"><?= htmlspecialchars($flashToast['message']) ?></p>
            </div>
            <button type="button" onclick="this.closest('.toast-item').remove()" class="text-slate-400 hover:text-slate-600">
                <i class="fa-solid fa-xmark text-sm"></i>
            </button>
        </div>
    <?php endif; ?>
</div>

<!-- Modal Dialog Global para Alertas de Erros e Contratos de Dados -->
<div id="global-modal" class="<?= $flashModal ? 'flex' : 'hidden' ?> fixed inset-0 z-50 items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm transition-opacity">
    <div class="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 transform transition-transform scale-100 animate-scaleUp">
        
        <?php
            $mType = $flashModal['type'] ?? 'info';
            $mIconBg = match ($mType) {
                'danger', 'error' => 'bg-rose-100 text-rose-600',
                'warning'         => 'bg-amber-100 text-amber-600',
                'success'         => 'bg-emerald-100 text-emerald-600',
                default           => 'bg-blue-100 text-blue-600',
            };
            $mIcon = match ($mType) {
                'danger', 'error' => 'fa-triangle-exclamation',
                'warning'         => 'fa-shield-halved',
                'success'         => 'fa-circle-check',
                default           => 'fa-circle-info',
            };
        ?>

        <div class="flex items-start gap-4">
            <div class="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 <?= $mIconBg ?>">
                <i id="modal-icon" class="fa-solid <?= $mIcon ?> text-2xl"></i>
            </div>
            <div class="flex-1">
                <div class="flex items-center justify-between">
                    <span class="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-600">
                        Aviso do Sistema
                    </span>
                    <button type="button" onclick="closeModal()" class="text-slate-400 hover:text-slate-600 p-1">
                        <i class="fa-solid fa-xmark text-base"></i>
                    </button>
                </div>
                <h3 id="modal-title" class="text-lg font-bold text-slate-900 mt-2">
                    <?= htmlspecialchars($flashModal['title'] ?? 'Atenção') ?>
                </h3>
                <p id="modal-message" class="text-sm text-slate-600 mt-2 leading-relaxed">
                    <?= htmlspecialchars($flashModal['message'] ?? '') ?>
                </p>
            </div>
        </div>

        <div class="mt-6 flex justify-end gap-3 pt-4 border-t border-slate-100">
            <button type="button" onclick="closeModal()" class="w-full sm:w-auto px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors">
                Entendido
            </button>
        </div>
    </div>
</div>

<script>
    function closeModal() {
        const modal = document.getElementById('global-modal');
        if (modal) {
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
    }

    // Auto-remover toasts após 6 segundos
    setTimeout(() => {
        const toasts = document.querySelectorAll('.toast-item');
        toasts.forEach(t => {
            t.classList.add('opacity-0', 'translate-y-2');
            setTimeout(() => t.remove(), 300);
        });
    }, 6000);

    // Função JS para abrir modal programaticamente
    window.openModalAlert = function(title, message, type = 'error') {
        const modal = document.getElementById('global-modal');
        const titleEl = document.getElementById('modal-title');
        const msgEl = document.getElementById('modal-message');
        const iconEl = document.getElementById('modal-icon');

        if (titleEl) titleEl.textContent = title;
        if (msgEl) msgEl.textContent = message;

        modal.classList.remove('hidden');
        modal.classList.add('flex');
    };
</script>
